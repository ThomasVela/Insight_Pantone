<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="css/ofertas.css">	

<body background="imagenes/fondo.jpg">

	<title></title>

<a href="bazar.php"><button style="margin-top: 10px;" type="submit" class="btn btn-primary">PAGINA INICIAL</button></a>

		<br><table style="float: right; ">
		<tr><th><br><img class="perfil" src="imagenes/usuario.png" alt="usuario"></th></tr>
		<tr><td><p><a href="editar perfil"></a></p>
			
			<center>
			<a href="">Ver Perfil</a>
			</center>

    </table>
				
				<br><h class="info">Nombre</h>
				<br><br><h class="info" >Diseñador</h>
				<br><br><br><h class="info" >No contratado</h>
				<div class="ofertas">


		<div id="oferta">
		<center>

		<h1>AREA PARA VISUALIZAR OFERTAS DE EMPLEO SUBIDAS RECIENTEMENTE</h1>

		    <br><label class="form-label">EMPRESA Y FECHA DE PUBLICACION</label><br>
		    		       <a style="color: #0b5292; font-size: 22px;" href=""><b>OFERTA DE EMPLEO DISPONIBLE</b></a><br> Descripcion.


		      <br><br><label class="form-label">EMPRESA Y FECHA DE PUBLICACION</label><br>
		    		       <a style="color: #0b5292; font-size: 22px;" href=""><b>OFERTA DE EMPLEO DISPONIBLE</b></a><br> DESCRIPCION


		    	  <br><br><label class="form-label">EMPRESA Y FECHA DE PUBLICACION</label><br>
		    		       <a style="color: #0b5292; font-size: 22px;" href=""><b>OFERTA DE EMPLEO DISPONIBLE</b></a><br> DESCRIPCION


		    	   <br><br><label class="form-label">EMPRESA Y FECHA DE PUBLICACION</label><br>
		    		       <a style="color: #0b5292; font-size: 22px;" href=""><b>OFERTA DE EMPLEO DISPONIBLE</b></a><br> DESCRIPCION


		    	     <br><br><label class="form-label">EMPRESA Y FECHA DE PUBLICACION</label><br>
		    		       <a style="color: #0b5292; font-size: 22px;" href=""><b>OFERTA DE EMPLEO DISPONIBLE</b></a><br> DESCRIPCION



		    		     <br><br><label class="form-label">EMPRESA Y FECHA DE PUBLICACION</label><br>
		    		       <a style="color: #0b5292; font-size: 22px;" href=""><b>OFERTA DE EMPLEO DISPONIBLE</b></a><br> DESCRIPCION

		    		     
		   


		</center>
	</div>
</div>
</td>
</tr>
</table>
</body>
</head>		 
</html>